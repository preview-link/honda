(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.bg1 = function() {
	this.initialize(img.bg1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,500);


(lib.bg2 = function() {
	this.initialize(img.bg2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,500);


(lib.bg3 = function() {
	this.initialize(img.bg3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,500);


(lib.bg4 = function() {
	this.initialize(img.bg4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.bg6 = function() {
	this.initialize(img.bg6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,500);


(lib.Bose12SpeakerAudioSystem = function() {
	this.initialize(img.Bose12SpeakerAudioSystem);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,126,108);


(lib.Combinedengineelectic = function() {
	this.initialize(img.Combinedengineelectic);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,169,71);


(lib.Convenience = function() {
	this.initialize(img.Convenience);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,74,40);


(lib.ehe = function() {
	this.initialize(img.ehe);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,233,43);


(lib.ending = function() {
	this.initialize(img.ending);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.ExperiencethenewpowerfulhybridSUVnow = function() {
	this.initialize(img.ExperiencethenewpowerfulhybridSUVnow);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,393,48);


(lib.FEELANEWSENSATIONOFPERFECTION = function() {
	this.initialize(img.FEELANEWSENSATIONOFPERFECTION);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,352,48);


(lib.hand = function() {
	this.initialize(img.hand);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,122,176);


(lib.HeadupDisplay = function() {
	this.initialize(img.HeadupDisplay);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,126,108);


(lib.learnmore2 = function() {
	this.initialize(img.learnmore2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,231,60);


(lib.PowerPanoramicSunroof = function() {
	this.initialize(img.PowerPanoramicSunroof);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,244,101);


(lib.Safety = function() {
	this.initialize(img.Safety);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,52,41);


(lib.Securitycopy = function() {
	this.initialize(img.Securitycopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,52,39);


(lib.Sportyinteriorwithredaccent = function() {
	this.initialize(img.Sportyinteriorwithredaccent);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,242,101);


(lib.Unleashthepowerofinnovation = function() {
	this.initialize(img.Unleashthepowerofinnovation);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,322,48);


(lib.WirelessChargingConsole_ = function() {
	this.initialize(img.WirelessChargingConsole_);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,125,210);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.wireless = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.WirelessChargingConsole_();
	this.instance.setTransform(-62.5,-105);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wireless, new cjs.Rectangle(-62.5,-105,125,210), null);


(lib.unlesh = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Unleashthepowerofinnovation();
	this.instance.setTransform(-80.5,-12,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.unlesh, new cjs.Rectangle(-80.5,-12,161,24), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ending();
	this.instance.setTransform(-150,-125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-125,300,250);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ending();
	this.instance.setTransform(-150,-125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-125,300,250);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bg2();
	this.instance.setTransform(-150,-125,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-150,-125,300,250), null);


(lib.sportyinter = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Sportyinteriorwithredaccent();
	this.instance.setTransform(-121,-50.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sportyinter, new cjs.Rectangle(-121,-50.5,242,101), null);


(lib.security = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Securitycopy();
	this.instance.setTransform(-26,-19.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.security, new cjs.Rectangle(-26,-19.5,52,39), null);


(lib.safety = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Safety();
	this.instance.setTransform(-26,-20.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.safety, new cjs.Rectangle(-26,-20.5,52,41), null);


(lib.panoramicsun = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.PowerPanoramicSunroof();
	this.instance.setTransform(-122,-50.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.panoramicsun, new cjs.Rectangle(-122,-50.5,244,101), null);


(lib.newsensation = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.FEELANEWSENSATIONOFPERFECTION();
	this.instance.setTransform(-88,-12,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.newsensation, new cjs.Rectangle(-88,-12,176,24), null);


(lib.learnmore = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.learnmore2();
	this.instance.setTransform(-57.75,-15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.learnmore, new cjs.Rectangle(-57.7,-15,115.5,30), null);


(lib.hev = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ehe();
	this.instance.setTransform(-116.5,-21.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.hev, new cjs.Rectangle(-116.5,-21.5,233,43), null);


(lib.headup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.HeadupDisplay();
	this.instance.setTransform(-63,-54);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.headup, new cjs.Rectangle(-63,-54,126,108), null);


(lib.hand2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.hand();
	this.instance.setTransform(-61,-88);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.hand2, new cjs.Rectangle(-61,-88,122,176), null);


(lib.flagship = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ExperiencethenewpowerfulhybridSUVnow();
	this.instance.setTransform(-98.25,-12,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.flagship, new cjs.Rectangle(-98.2,-12,196.5,24), null);


(lib.convenience = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Convenience();
	this.instance.setTransform(-37,-20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.convenience, new cjs.Rectangle(-37,-20,74,40), null);


(lib.bose12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bose12SpeakerAudioSystem();
	this.instance.setTransform(-63,-54);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bose12, new cjs.Rectangle(-63,-54,126,108), null);


(lib.bg6_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bg6();
	this.instance.setTransform(-150,-125,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg6_1, new cjs.Rectangle(-150,-125,300,250), null);


(lib.bg4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bg4();
	this.instance.setTransform(-150,-125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg4_1, new cjs.Rectangle(-150,-125,300,250), null);


(lib.bg3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bg3();
	this.instance.setTransform(-150,-125,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg3_1, new cjs.Rectangle(-150,-125,300,250), null);


(lib._207 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Combinedengineelectic();
	this.instance.setTransform(-84.5,-35.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._207, new cjs.Rectangle(-84.5,-35.5,169,71), null);


// stage content:
(lib.Untitled2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_50
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(150,125);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},344).to({state:[{t:this.instance_1}]},5).wait(16));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(344).to({_off:false},0).to({_off:true,alpha:1},5,cjs.Ease.quadIn).wait(16));

	// learn_more2_png
	this.instance_2 = new lib.learnmore();
	this.instance_2.setTransform(149.75,254);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(299).to({_off:false},0).to({y:224,alpha:1},15,cjs.Ease.quadIn).to({regY:-0.4,scaleX:1.1008,scaleY:1.1,x:149,y:222.45},27).wait(24));

	// Experience_the_new_powerful_hybrid_SUV_now__png
	this.instance_3 = new lib.flagship();
	this.instance_3.setTransform(150.25,223);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(299).to({_off:false},0).to({y:193,alpha:1},10,cjs.Ease.quadIn).wait(56));

	// bg6_jpg
	this.instance_4 = new lib.bg6_1();
	this.instance_4.setTransform(150,124.95);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(294).to({_off:false},0).to({alpha:1},5,cjs.Ease.quadInOut).wait(45).to({y:125},5,cjs.Ease.quadIn).wait(16));

	// Bose_12_Speaker_Audio_System_png
	this.instance_5 = new lib.bose12();
	this.instance_5.setTransform(195,-19.5);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(219).to({_off:false},0).to({y:91,alpha:1},9,cjs.Ease.quadInOut).wait(21).to({regX:0.1,scaleX:1.0714,scaleY:1.0708,x:194.8,y:90.5},5,cjs.Ease.quadInOut).wait(10).to({y:90.6},0).to({regY:-0.1,scaleX:1,scaleY:0.9995,y:90.5},5,cjs.Ease.quadInOut).wait(30).to({_off:true},1).wait(65));

	// Head_up_Display_png
	this.instance_6 = new lib.headup();
	this.instance_6.setTransform(196,81.5);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(219).to({_off:false},0).to({y:192,alpha:1},9,cjs.Ease.quadInOut).wait(41).to({regX:0.1,regY:-0.2,scaleX:1.0714,scaleY:1.0708,x:195.7,y:191.1},5,cjs.Ease.quadInOut).wait(10).to({regX:0,regY:0,scaleX:1,scaleY:1,x:196,y:192},5,cjs.Ease.quadInOut).wait(10).to({_off:true},1).wait(65));

	// Wireless_Charging_Console__png
	this.instance_7 = new lib.wireless();
	this.instance_7.setTransform(71.5,252.5);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(219).to({_off:false},0).to({y:142,alpha:1},9,cjs.Ease.quadInOut).to({regY:-0.2,scaleX:1.056,scaleY:1.056,x:71.3,y:141.35},5,cjs.Ease.quadInOut).wait(11).to({regY:-0.1,scaleX:1,scaleY:0.9998,y:141.45},5,cjs.Ease.quadInOut).wait(50).to({regY:0,scaleY:1,x:71.5,y:142},0).to({_off:true},1).wait(65));

	// Unleash_the_power_of_innovation_png
	this.instance_8 = new lib.unlesh();
	this.instance_8.setTransform(-86.9,22.95);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(219).to({_off:false},0).to({x:95.1,alpha:1},9,cjs.Ease.quadInOut).wait(71).to({_off:true},1).wait(65));

	// Sporty_interior_with_red_accent_png
	this.instance_9 = new lib.sportyinter();
	this.instance_9.setTransform(133,45);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(159).to({_off:false},0).to({y:90.5,alpha:1},8).to({regY:-0.2,scaleX:1.0703,scaleY:1.0698,x:132.65,y:89.95},4,cjs.Ease.quadInOut).wait(11).to({regY:0,scaleX:1,scaleY:1,x:133,y:90.5},0).wait(32).to({y:45,alpha:0},5,cjs.Ease.quadInOut).to({_off:true},1).wait(145));

	// Power_Panoramic_Sunroof_png
	this.instance_10 = new lib.panoramicsun();
	this.instance_10.setTransform(134,237);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(159).to({_off:false},0).to({y:191.5,alpha:1},8).wait(15).to({regY:-0.1,scaleX:1.0451,scaleY:1.0451,x:133.55,y:191},5,cjs.Ease.quadInOut).wait(12).to({regY:0,scaleX:1,scaleY:1,x:134,y:191.5},0).wait(15).to({y:269.5,alpha:0},5,cjs.Ease.quadInOut).to({_off:true},1).wait(145));

	// FEEL_A_NEW_SENSATION_OF_PERFECTION_png
	this.instance_11 = new lib.newsensation();
	this.instance_11.setTransform(-96,26);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(159).to({_off:false},0).to({x:99,alpha:1},8).wait(47).to({x:-70,alpha:0},5,cjs.Ease.quadInOut).to({_off:true},1).wait(145));

	// bg4_jpg
	this.instance_12 = new lib.bg4_1();
	this.instance_12.setTransform(150,125);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(154).to({_off:false},0).to({alpha:1},5,cjs.Ease.quadIn).wait(140).to({_off:true},1).wait(65));

	// ehe_png
	this.instance_13 = new lib.hev();
	this.instance_13.setTransform(-126,29.5);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(99).to({_off:false},0).to({x:127.5},10,cjs.Ease.quadOut).wait(50).to({_off:true},1).wait(205));

	// Combined_engine___electic_png
	this.instance_14 = new lib._207();
	this.instance_14.setTransform(150.5,209.5);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(99).to({_off:false},0).to({alpha:1},10,cjs.Ease.quadOut).to({regX:0.1,regY:-0.2,scaleX:1.1242,scaleY:1.1232,x:149.8,y:208.15},7).wait(28).to({regX:0,regY:0,scaleX:1,scaleY:1,x:150.5,y:209.5},5,cjs.Ease.quadInOut).wait(10).to({_off:true},1).wait(205));

	// bg3_jpg
	this.instance_15 = new lib.bg3_1();
	this.instance_15.setTransform(151,125.95,1.0667,1.0666);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(91).to({_off:false},0).to({alpha:1},8).to({scaleX:1.02,scaleY:1.0198,x:150.95,y:125.9},60).to({_off:true},1).wait(205));

	// Convenience_png
	this.instance_16 = new lib.convenience();
	this.instance_16.setTransform(248,106.05,0.0135,0.025,0,0,0,0,2);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(62).to({_off:false},0).to({regY:0,scaleX:1,scaleY:1,y:106},10,cjs.Ease.elasticInOut).wait(27).to({_off:true},1).wait(265));

	// Security_copy_png
	this.instance_17 = new lib.security();
	this.instance_17.setTransform(186,80.6,0.0192,0.0256,0,0,0,2.6,0);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(52).to({_off:false},0).to({regX:0,scaleX:1,scaleY:1,y:80.5},13,cjs.Ease.elasticInOut).wait(34).to({_off:true},1).wait(265));

	// Safety_png
	this.instance_18 = new lib.safety();
	this.instance_18.setTransform(124,90.6,0.0192,0.0244,0,0,0,2.6,0);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(45).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:0.9808,scaleY:0.9792,x:124.05,y:90.7},13,cjs.Ease.elasticInOut).wait(41).to({_off:true},1).wait(265));

	// hand_png
	this.instance_19 = new lib.hand2();
	this.instance_19.setTransform(-62,163);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(39).to({_off:false},0).to({x:68},10,cjs.Ease.quadInOut).wait(50).to({_off:true},1).wait(265));

	// bg2_jpg
	this.instance_20 = new lib.Symbol1();
	this.instance_20.setTransform(150,125);
	this.instance_20.alpha = 0;
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(29).to({_off:false},0).to({alpha:1},10,cjs.Ease.quadInOut).wait(60).to({_off:true},1).wait(265));

	// bg1_jpg
	this.instance_21 = new lib.bg1();
	this.instance_21.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(39).to({_off:true},1).wait(325));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-92.5,51.5,403.6,306);
// library properties:
lib.properties = {
	id: '479EC6F55FED02439DCDEC09A7ED200E',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg1.jpg", id:"bg1"},
		{src:"images/bg2.jpg", id:"bg2"},
		{src:"images/bg3.jpg", id:"bg3"},
		{src:"images/bg4.jpg", id:"bg4"},
		{src:"images/bg6.jpg", id:"bg6"},
		{src:"images/Bose12SpeakerAudioSystem.png", id:"Bose12SpeakerAudioSystem"},
		{src:"images/Combinedengineelectic.png", id:"Combinedengineelectic"},
		{src:"images/Convenience.png", id:"Convenience"},
		{src:"images/ehe.png", id:"ehe"},
		{src:"images/ending.jpg", id:"ending"},
		{src:"images/ExperiencethenewpowerfulhybridSUVnow.png", id:"ExperiencethenewpowerfulhybridSUVnow"},
		{src:"images/FEELANEWSENSATIONOFPERFECTION.png", id:"FEELANEWSENSATIONOFPERFECTION"},
		{src:"images/hand.png", id:"hand"},
		{src:"images/HeadupDisplay.png", id:"HeadupDisplay"},
		{src:"images/learnmore2.png", id:"learnmore2"},
		{src:"images/PowerPanoramicSunroof.png", id:"PowerPanoramicSunroof"},
		{src:"images/Safety.png", id:"Safety"},
		{src:"images/Securitycopy.png", id:"Securitycopy"},
		{src:"images/Sportyinteriorwithredaccent.png", id:"Sportyinteriorwithredaccent"},
		{src:"images/Unleashthepowerofinnovation.png", id:"Unleashthepowerofinnovation"},
		{src:"images/WirelessChargingConsole_.png", id:"WirelessChargingConsole_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['479EC6F55FED02439DCDEC09A7ED200E'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;